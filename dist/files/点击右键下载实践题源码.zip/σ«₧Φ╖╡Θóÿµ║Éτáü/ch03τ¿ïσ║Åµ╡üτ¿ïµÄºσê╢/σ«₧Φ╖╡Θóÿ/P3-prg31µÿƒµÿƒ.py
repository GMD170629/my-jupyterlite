import turtle
for i in range(4):
    turtle.circle(-90,90)
    turtle.right(180)