i=10;sumAll=0
while(i>=1):
    sumAll+=i
    i-=1
print(sumAll)
input()
