import turtle as t
t.right(-30)             #改变出发角度
for i in range(2):   #在此循环中,i取值为0和1
    t.fd(200)
    t.right(60*(i+1))
for i in range(2): 
    t.fd(200)
    t.right(60*(i+1))
