i=2;sumEven=0
while(i<=100):
    sumEven+=i
    i+=2
print(sumEven)
input()
