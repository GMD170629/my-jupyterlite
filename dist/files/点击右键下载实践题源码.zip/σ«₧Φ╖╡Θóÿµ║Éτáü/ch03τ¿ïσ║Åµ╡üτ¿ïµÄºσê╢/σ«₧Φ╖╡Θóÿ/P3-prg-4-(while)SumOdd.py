i=1;sumOdd=0
while(i<=99):
    sumOdd+=i
    i+=2
print(sumOdd)
input()
