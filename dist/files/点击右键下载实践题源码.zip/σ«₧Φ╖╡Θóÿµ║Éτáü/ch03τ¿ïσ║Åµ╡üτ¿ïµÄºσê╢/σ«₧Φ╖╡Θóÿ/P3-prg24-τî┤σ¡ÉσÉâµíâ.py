p = 1 #第8天桃子数为1
for i in range(8, 0,-1):
    print("第",i,"天桃子数为：",p)
    p = 2 * (p + 1)
