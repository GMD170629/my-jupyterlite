import turtle as t
for i in range(6):
    t.fd(100)
    t.left(60)
