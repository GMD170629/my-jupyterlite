s=0
for i in range(10,0,-1):
    s+=i
print(s)
