#求 a 的算术平方根的近似方法
a = float(input("请输入>=0的实数a："))
if a<=0:
   print("a必须大于等于0")
else:
    x0 = a;x1 = (x0 + a / x0) / 2
    while (abs(x1 - x0) > pow(10, -6)):
        x0 = x1; x1 = (x0 + a / x0) / 2
    print( a,"的算术平方根=",x1)


