p = 1 #第8天桃子数为1
for i in range(8, 0,-1):
    p = 2 * (p + 1)
print(p/2-1)
