import turtle
d=0
for i in range(4):
    turtle.right(90)
    turtle.circle(50,180)

