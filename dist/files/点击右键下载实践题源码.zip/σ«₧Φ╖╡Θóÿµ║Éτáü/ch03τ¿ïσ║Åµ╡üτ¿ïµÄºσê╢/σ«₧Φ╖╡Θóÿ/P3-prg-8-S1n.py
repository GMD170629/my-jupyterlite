s=0;n=5
for i in range(1,n+1):
    s+=1/i
print(s)
