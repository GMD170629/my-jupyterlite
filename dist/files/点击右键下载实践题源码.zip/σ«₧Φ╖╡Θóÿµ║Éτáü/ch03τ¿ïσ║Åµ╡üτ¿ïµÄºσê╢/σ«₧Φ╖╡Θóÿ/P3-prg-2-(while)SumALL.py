i=0;sumAll=0
while(i<=100):
    sumAll+=i
    i+=1
print("1~100中所有数的和为:", sumAll)
input()
