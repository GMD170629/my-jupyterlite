import turtle as t
for i in range(3):
    t.seth(i* 120)
    t.fd(200)
