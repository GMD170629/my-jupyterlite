#string.py
print("1".center(20))         #1行20个字符，居中对齐
print("1 1".center(20))        #1行20个字符，居中对齐
print(format("1 2 1", "^20"))  #1行20个字符，居中对齐
print(format("1 3 3 1", "^20"))  #1行20个字符，居中对齐
print(format("1 4 6 4 1", "^20"))
input()
