d=dict({1:'Mon', 2:'Tues',3:'Wed', 4:'Thur',5:'Fri', 6:'Sat',7:'Sun'})
for k in d.keys():
    print(k, end=" ")
print("\n")
for v in d.values():
    print(v, end=" ")
print("\n")
for item in d.items():
    print(item, end=' ')
