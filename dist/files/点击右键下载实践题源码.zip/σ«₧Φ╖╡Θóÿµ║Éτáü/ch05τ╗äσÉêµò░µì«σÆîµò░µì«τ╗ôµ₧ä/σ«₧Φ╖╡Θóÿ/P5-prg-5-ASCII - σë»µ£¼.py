s = input("请输入一个字符串:")
list1 = []
for i in range(len(s)):
        num = ord(s[i])
        list1.append(num)
print(list1)


