def aFunction():
    "精诚所至，金石为开"
    return 1
print(aFunction.__doc__[5:10])
